# Contributing to GitHub

[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com)

**Working on your first Pull Request?** You can learn how from this *free* in-depth series, [How to Contribute to an Open Source Project on GitHub](https://egghead.io/series/how-to-contribute-to-an-open-source-project-on-github).

Or, for you *Do It Yourself* (DIY) folks who wants to learn it fairly quickly, you can try learning from this **easy-to-follow guide**, [How to Contribute to Open Source](https://opensource.guide/how-to-contribute), by [Open Source Guides](https://opensource.guide/).
