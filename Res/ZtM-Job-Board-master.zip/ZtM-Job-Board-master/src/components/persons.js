// IMPORTANT!
// If you wish to change the name or location of the persons.json file, Please drop @matt#8280 (Discord) or
// @mattcsmith (Github) a message, I rely on this file for another upcoming project, and would therefor
// appreciate the heads up and opportunity to modify the code on the other project. 
export const persons = require('../assets/persons.json')
